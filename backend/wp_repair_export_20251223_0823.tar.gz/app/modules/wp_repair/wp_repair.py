# wp_repair.py — Single entry point (API / Orchestrator)
#
# Responsibilities
# - Expose endpoints for the internal Repair Wizard (employees).
# - Coordinate workflow steps:
#   1) SFTP connect
#   2) project discovery + selection
#   3) wp-root selection
#   4) diagnose
#   5) run a selected fix module
#   6) rollback
#
# What should NOT live here
# - No fix logic (htaccess/permissions/malware/etc.). Those live under modules/.
# - No templates/rules. Those live inside each module.
# app/modules/wp_repair/wp_repair.py
from __future__ import annotations

import time
import secrets
import json
import posixpath
from typing import Dict, Any

from flask import Blueprint, jsonify, request, current_app

# Module imports (deine Skeleton-Struktur)
from .modules.sftp.connect import sftp_connect
from .modules.sftp.projects import sftp_discover_projects
from .modules.sftp.explorer import sftp_ls_safe
from .modules.diagnose.diagnose import run_diagnose
from .modules.sftp.find_wp_root import find_wp_roots
from .modules.sftp.explorer import sftp_path_is_dir
from .modules.audit.actions import ensure_dirs, create_action, append_log, quarantine_move, rollback, read_text_remote, write_text_remote
from .modules.htaccess.fix import apply_htaccess_fix
from .modules.maintenance.fix import maintenance_exists
from .modules.permissions.fix import permissions_preview, permissions_apply
from .modules.maintenance.remove import remove_maintenance
from .modules.dropins.preview import dropins_preview
from .modules.dropins.fix import dropins_apply_disable
#from .modules.core.preview import core_integrity_preview
#from .modules.core.replace_preview import core_replace_preview
#from .modules.core.replace_apply import core_replace_apply
from .modules.core.replace_preview import core_replace_preview as core_replace_preview_fn
from .modules.core.replace_apply import core_replace_apply as core_replace_apply_fn
from .modules.core.preview import core_integrity_preview





bp = Blueprint("wp_repair", __name__, url_prefix="/api/wp-repair")

@bp.errorhandler(Exception)
def _repair_error(err):
    current_app.logger.exception("Unhandled wp_repair error")
    return jsonify({"ok": False, "error": str(err)}), 500

# ------------------------------------------------------------
# Simple in-memory session store (für Start ok)
# Später ersetzen durch Redis/DB, damit Restarts kein Problem sind.
# ------------------------------------------------------------
_SESSIONS: Dict[str, Dict[str, Any]] = {}
_SESSION_TTL_SECONDS = 60 * 30  # 30 Minuten


def _now() -> int:
    return int(time.time())


def _cleanup_sessions() -> None:
    now = _now()
    expired = [sid for sid, v in _SESSIONS.items() if now - v.get("ts", now) > _SESSION_TTL_SECONDS]
    for sid in expired:
        _SESSIONS.pop(sid, None)


def _get_session(session_id: str) -> Dict[str, Any]:
    _cleanup_sessions()
    s = _SESSIONS.get(session_id)
    if not s:
        raise ValueError("Invalid or expired session_id")
    # touch
    s["ts"] = _now()
    return s

def _ensure_context(s: dict, data: dict) -> tuple[str | None, str | None]:
    # allow passing context in any POST
    pr = (data.get("project_root") or s.get("project_root") or "").strip()
    wr = (data.get("wp_root") or s.get("wp_root") or "").strip()

    if pr:
        s["project_root"] = pr
    if wr:
        # safety: wp_root must be inside project_root if project_root is known
        if pr:
            prn = pr.rstrip("/")
            if wr != prn and not wr.startswith(prn + "/"):
                raise ValueError("wp_root outside selected project_root")
        s["wp_root"] = wr

    return (s.get("project_root"), s.get("wp_root"))

@bp.get("/health")
def health():
    return jsonify({"ok": True})

@bp.post("/session/start")
def api_session_start():
    """
    Start session from frontend-provided ticket data.
    Expected JSON:
    {
      "domain": "...",
      "ftp_host": "...",
      "ftp_user": "...",
      "ftp_pass": "...",
      "ftp_port": 22   # optional
    }
    """
    data = request.get_json(silent=True) or {}

    domain = (data.get("domain") or "").strip()

    host = (data.get("ftp_host") or data.get("sftp_host") or "").strip()
    username = (data.get("ftp_user") or data.get("sftp_user") or "").strip()
    password = data.get("ftp_pass") or data.get("sftp_pass") or ""
    port = int(data.get("ftp_port") or data.get("sftp_port") or 22)

    if not host or not username or not password:
        return jsonify({"ok": False, "error": "Missing SFTP credentials (ftp_host/ftp_user/ftp_pass)"}), 400

    session_id = secrets.token_urlsafe(24)
    _SESSIONS[session_id] = {
        "ts": _now(),
        "host": host,
        "port": port,
        "username": username,
        "password": password,  # nur im RAM
        "domain": domain,

        # optional aus Ticket (für später, aktuell nicht nötig)
        "website_user": (data.get("website_user") or "").strip(),
        "website_pass": (data.get("website_pass") or ""),
        "website_login": (data.get("website_login") or "").strip(),

        "project_root": None,
        "wp_root": None,
    }

    return jsonify({"ok": True, "session_id": session_id})

# ------------------------------------------------------------
# 1) SFTP connect
# ------------------------------------------------------------
@bp.post("/sftp/connect")
def api_sftp_connect():
    """
    Body JSON example:
    {
      "host": "example.com",
      "port": 22,
      "username": "user",
      "password": "secret"
    }
    """
    data = request.get_json(silent=True) or {}
    host = (data.get("host") or "").strip()
    port = int(data.get("port") or 22)
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if not host or not username or not password:
        return jsonify({"ok": False, "error": "Missing host/username/password"}), 400

    # Connect and store minimal connection data (kein Password loggen!)
    try:
        client_handle = sftp_connect(host=host, port=port, username=username, password=password)
    except Exception as e:
        current_app.logger.exception("SFTP connect failed")
        return jsonify({"ok": False, "error": str(e)}), 400

    session_id = secrets.token_urlsafe(24)
    _SESSIONS[session_id] = {
        "ts": _now(),
        "host": host,
        "port": port,
        "username": username,
        # password NICHT speichern in Logs; für Start speichern wir es im RAM.
        # Später: verschlüsselt/Token/Secret store.
        "password": password,
        # Optional: cache selected project/wp_root
        "project_root": None,
        "wp_root": None,
    }

    # Client handle schließen wir sofort; wir reconnecten pro Request (stabiler).
    try:
        client_handle.close()
    except Exception:
        pass

    return jsonify({"ok": True, "session_id": session_id})


# ------------------------------------------------------------
# 2) Projects discover
# ------------------------------------------------------------
@bp.get("/sftp/projects")
def api_sftp_projects():
    session_id = (request.args.get("session_id") or "").strip()
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        items = sftp_discover_projects(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"]
        )
        return jsonify({"ok": True, "items": items})
    except Exception as e:
        current_app.logger.exception("Project discovery failed")
        return jsonify({"ok": False, "error": str(e)}), 400


# ------------------------------------------------------------
# 3) Explorer ls (safe)
# ------------------------------------------------------------
@bp.get("/sftp/ls")
def api_sftp_ls():
    session_id = (request.args.get("session_id") or "").strip()
    path = request.args.get("path") or "/"
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)

        boundary = s.get("project_root")
        if not boundary:
            return jsonify({"ok": False, "error": "No project selected (call /sftp/select_project first)"}), 400

        items = sftp_ls_safe(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            path=path, boundary_root=boundary
        )
        return jsonify({"ok": True, "items": items, "boundary_root": boundary})
    except Exception as e:
        current_app.logger.exception("SFTP ls failed")
        return jsonify({"ok": False, "error": str(e)}), 400


# ------------------------------------------------------------
# 4) Diagnose
# ------------------------------------------------------------
@bp.post("/diagnose")
def api_diagnose():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    wp_root = (data.get("wp_root") or "").strip()

    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)

        if not wp_root:
            wp_root = (s.get("wp_root") or "").strip()

        if not wp_root:
            return jsonify({"ok": False, "error": "Missing wp_root (call /sftp/find_wp_root or provide wp_root)"}), 400

        s["wp_root"] = wp_root

        result = run_diagnose(
            host=s["host"],
            port=s["port"],
            username=s["username"],
            password=s["password"],
            wp_root=wp_root,
        )

        return jsonify({"ok": True, "diagnose": result})
    except Exception as e:
        current_app.logger.exception("Diagnose failed")
        return jsonify({"ok": False, "error": str(e)}), 400


# --- NEW: select project root and store in session ---
@bp.post("/sftp/select_project")
def api_sftp_select_project():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    project_root = (data.get("project_root") or "").strip()

    if not session_id or not project_root:
        return jsonify({"ok": False, "error": "Missing session_id/project_root"}), 400

    try:
        s = _get_session(session_id)

        # validate exists and is directory
        if not sftp_path_is_dir(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            path=project_root
        ):
            return jsonify({"ok": False, "error": "project_root does not exist or is not a directory"}), 400

        s["project_root"] = project_root
        # reset wp_root when project changes
        s["wp_root"] = None

        return jsonify({"ok": True, "project_root": project_root})
    except Exception as e:
        current_app.logger.exception("Select project failed")
        return jsonify({"ok": False, "error": str(e)}), 400


@bp.post("/sftp/find_wp_root")
def api_sftp_find_wp_root():
    """
    Body JSON:
    {
      "session_id": "...",
      "max_depth": 4
    }
    Uses selected project_root from session.
    Stores best candidate into session.wp_root.
    """
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    max_depth = int(data.get("max_depth") or 4)

    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        project_root = s.get("project_root")
        if not project_root:
            return jsonify({"ok": False, "error": "No project selected (call /sftp/select_project first)"}), 400

        candidates = find_wp_roots(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            project_root=project_root, max_depth=max_depth
        )

        # store best candidate
        best = candidates[0]["wp_root"] if candidates else None
        s["wp_root"] = best

        return jsonify({"ok": True, "project_root": project_root, "wp_root": best, "candidates": candidates})
    except Exception as e:
        current_app.logger.exception("Find WP root failed")
        return jsonify({"ok": False, "error": str(e)}), 400

@bp.post("/sftp/select_wp_root")
def api_sftp_select_wp_root():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    wp_root = (data.get("wp_root") or "").strip()

    if not session_id or not wp_root:
        return jsonify({"ok": False, "error": "Missing session_id/wp_root"}), 400

    try:
        s = _get_session(session_id)
        if not s.get("project_root"):
            return jsonify({"ok": False, "error": "No project selected"}), 400

        # safety: wp_root must be inside project_root
        pr = s["project_root"].rstrip("/")
        if wp_root != pr and not wp_root.startswith(pr + "/"):
            return jsonify({"ok": False, "error": "wp_root outside selected project"}), 400

        s["wp_root"] = wp_root
        return jsonify({"ok": True, "wp_root": wp_root})
    except Exception as e:
        current_app.logger.exception("Select wp_root failed")
        return jsonify({"ok": False, "error": str(e)}), 400

@bp.post("/rollback")
def api_rollback():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    action_id = (data.get("action_id") or "").strip()

    if not session_id or not action_id:
        return jsonify({"ok": False, "error": "Missing session_id/action_id"}), 400

    try:
        s = _get_session(session_id)
        wp_root = (s.get("wp_root") or "").strip()
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        base = ensure_dirs(s["host"], s["port"], s["username"], s["password"], wp_root)["base"]
        meta_path = f"{base}/quarantine/actions/{action_id}/meta.json"

        meta = rollback(s["host"], s["port"], s["username"], s["password"], meta_path)

        append_log(
            s["host"], s["port"], s["username"], s["password"], wp_root,
            {"ts": int(time.time()), "type": "rollback", "action_id": action_id, "fix_id": meta.get("fix_id"), "ok": True}
        )

        return jsonify({"ok": True, "meta": meta})
    except Exception as e:
        current_app.logger.exception("Rollback failed")
        return jsonify({"ok": False, "error": str(e)}), 400


@bp.post("/fix/htaccess")
def api_fix_htaccess():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    template = (data.get("template") or "single.htaccess").strip()

    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        wp_root = (s.get("wp_root") or "").strip()
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        # 1) action erstellen
        action = create_action(
            s["host"], s["port"], s["username"], s["password"],
            wp_root=wp_root,
            fix_id="htaccess",
            context={"template": template}
        )

        # 2) existierende .htaccess in Quarantäne verschieben (wenn vorhanden)
        ht_path = f"{wp_root.rstrip('/')}/.htaccess"
        try:
            quarantine_move(
                s["host"], s["port"], s["username"], s["password"],
                src_path=ht_path,
                moved_dir=action["moved_dir"],
                meta_path=action["meta_path"]
            )
            moved = True
        except Exception:
            moved = False  # file may not exist; ok

        # 3) neuen htaccess schreiben
        res = apply_htaccess_fix(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            wp_root=wp_root, template=template
        )

        # 4) log
        append_log(
            s["host"], s["port"], s["username"], s["password"], wp_root,
            {
                "ts": int(time.time()),
                "type": "fix",
                "fix_id": "htaccess",
                "action_id": action["action_id"],
                "ok": True,
                "details": {"template": template, "moved_old": moved}
            }
        )

        return jsonify({"ok": True, "action_id": action["action_id"], "result": res})
    except Exception as e:
        current_app.logger.exception("htaccess fix failed")
        return jsonify({"ok": False, "error": str(e)}), 400





@bp.post("/permissions/preview")
def api_permissions_preview():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    rules = data.get("rules") or {}

    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        res = permissions_preview(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            wp_root=wp_root, rules=rules
        )
        return jsonify(res)
    except Exception as e:
        current_app.logger.exception("permissions preview failed")
        return jsonify({"ok": False, "error": str(e)}), 400


@bp.post("/permissions/apply")
def api_permissions_apply():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    rules = data.get("rules") or {}

    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        # create action
        action = create_action(
            s["host"], s["port"], s["username"], s["password"],
            wp_root=wp_root, fix_id="permissions",
            context={"rules": rules}
        )

        res = permissions_apply(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            wp_root=wp_root, rules=rules
        )

        # patch meta.json with chmod list for rollback
        meta_txt = read_text_remote(s["host"], s["port"], s["username"], s["password"], action["meta_path"])
        meta = json.loads(meta_txt)
        meta["chmod"] = res.get("changed", [])
        meta["status"] = "applied"
        write_text_remote(s["host"], s["port"], s["username"], s["password"], action["meta_path"],
                          json.dumps(meta, ensure_ascii=False, indent=2))

        append_log(
            s["host"], s["port"], s["username"], s["password"], wp_root,
            {
                "ts": int(time.time()),
                "type": "fix",
                "fix_id": "permissions",
                "action_id": action["action_id"],
                "ok": True,
                "details": {"changed": len(res.get("changed", [])), "errors": len(res.get("errors", []))}
            }
        )

        return jsonify({"ok": True, "action_id": action["action_id"], "result": res})
    except Exception as e:
        current_app.logger.exception("permissions apply failed")
        return jsonify({"ok": False, "error": str(e)}), 400


# 3) add the endpoint (place near other fix endpoints):
@bp.post("/fix/maintenance/remove")
def api_fix_maintenance_remove():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        # create action early so we can quarantine for rollback
        action = create_action(
            s["host"], s["port"], s["username"], s["password"],
            wp_root=wp_root, fix_id="maintenance",
            context={}
        )

        res = remove_maintenance(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            wp_root=wp_root
        )

        meta_txt = read_text_remote(s["host"], s["port"], s["username"], s["password"], action["meta_path"])
        meta = json.loads(meta_txt)

        if res.get("skipped"):
            meta["status"] = "skipped"
            write_text_remote(
                s["host"], s["port"], s["username"], s["password"],
                action["meta_path"], json.dumps(meta, ensure_ascii=False, indent=2)
            )
            append_log(
                s["host"], s["port"], s["username"], s["password"], wp_root,
                {"ts": int(time.time()), "type": "fix", "fix_id": "maintenance", "action_id": action["action_id"], "ok": True, "skipped": True}
            )
            return jsonify({"ok": True, "action_id": action["action_id"], "result": res, "skipped": True})

        # quarantine the .maintenance file for rollback
                # quarantine-move the .maintenance file for rollback (this also "removes" it from wp_root)
        moved_to = quarantine_move(
            s["host"], s["port"], s["username"], s["password"],
            res["path"], action["moved_dir"], action["meta_path"]
        )

        meta_txt = read_text_remote(s["host"], s["port"], s["username"], s["password"], action["meta_path"])
        meta = json.loads(meta_txt)
        meta["status"] = "applied"
        meta.setdefault("notes", []).append(f"moved {res['path']} -> {moved_to}")
        write_text_remote(
            s["host"], s["port"], s["username"], s["password"],
            action["meta_path"], json.dumps(meta, ensure_ascii=False, indent=2)
        )

        append_log(
            s["host"], s["port"], s["username"], s["password"], wp_root,
            {"ts": int(time.time()), "type": "fix", "fix_id": "maintenance", "action_id": action["action_id"], "ok": True, "skipped": False}
        )

        return jsonify({"ok": True, "action_id": action["action_id"], "result": {"ok": True, "path": res["path"], "moved_to": moved_to}})

    except Exception as e:
        current_app.logger.exception("maintenance remove failed")
        return jsonify({"ok": False, "error": str(e)}), 400


@bp.post("/fix/dropins/preview")
def api_fix_dropins_preview():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        res = dropins_preview(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            wp_root=wp_root
        )
        return jsonify(res)
    except Exception as e:
        current_app.logger.exception("dropins preview failed")
        return jsonify({"ok": False, "error": str(e)}), 400


@bp.post("/fix/dropins/apply")
def api_fix_dropins_apply():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        disable = data.get("disable")  # optional list
        plan = dropins_apply_disable(
            host=s["host"], port=s["port"], username=s["username"], password=s["password"],
            wp_root=wp_root, disable=disable
        )

        action = create_action(
            s["host"], s["port"], s["username"], s["password"],
            wp_root=wp_root, fix_id="dropins",
            context={"mode": "disable", "disable": plan.get("requested", [])}
        )

        # nothing to do -> skip
        if not plan["found"]:
            meta = json.loads(read_text_remote(s["host"], s["port"], s["username"], s["password"], action["meta_path"]))
            meta["status"] = "skipped"
            meta.setdefault("notes", []).append("No dropins found to disable")
            write_text_remote(
                s["host"], s["port"], s["username"], s["password"],
                action["meta_path"], json.dumps(meta, ensure_ascii=False, indent=2)
            )
            append_log(
                s["host"], s["port"], s["username"], s["password"], wp_root,
                {"ts": int(time.time()), "type": "fix", "fix_id": "dropins", "action_id": action["action_id"], "ok": True, "skipped": True}
            )
            return jsonify({"ok": True, "action_id": action["action_id"], "result": plan, "skipped": True})

        moved = []
        for t in plan["found"]:
            moved_to = quarantine_move(
                s["host"], s["port"], s["username"], s["password"],
                t["path"], action["moved_dir"], action["meta_path"]
            )
            moved.append({"name": t["name"], "src": t["path"], "dst": moved_to})

        meta = json.loads(read_text_remote(s["host"], s["port"], s["username"], s["password"], action["meta_path"]))
        meta["status"] = "applied"
        meta.setdefault("notes", []).append(f"disabled {len(moved)} dropin(s)")
        meta.setdefault("result", {})["moved"] = moved
        write_text_remote(
            s["host"], s["port"], s["username"], s["password"],
            action["meta_path"], json.dumps(meta, ensure_ascii=False, indent=2)
        )

        append_log(
            s["host"], s["port"], s["username"], s["password"], wp_root,
            {"ts": int(time.time()), "type": "fix", "fix_id": "dropins", "action_id": action["action_id"], "ok": True, "skipped": False}
        )

        return jsonify({"ok": True, "action_id": action["action_id"], "result": {"plan": plan, "moved": moved}})
    except Exception as e:
        current_app.logger.exception("dropins apply failed")
        return jsonify({"ok": False, "error": str(e)}), 400

@bp.post("/core/preview")
def api_core_preview():
    """
    Body JSON:
    {
      "session_id": "...",
      "wp_root": "...",          # optional, wenn bereits in Session
      "wp_version": "6.8",       # optional (wenn weggelassen, wird version.php gelesen)
      "max_files": 2500,         # optional
      "include_ok": false        # optional
    }
    """
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)

        # nutzt eure bestehende Context-Logik (Session wp_root oder Body wp_root)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        wp_version = (data.get("wp_version") or "").strip() or None
        max_files = int(data.get("max_files") or 2500)
        include_ok = bool(data.get("include_ok") or False)

        res = core_integrity_preview(
            host=s["host"],
            port=s["port"],
            username=s["username"],
            password=s["password"],
            wp_root=wp_root,
            wp_version=wp_version,
            max_files=max_files,
            include_ok=include_ok,
        )

        # core_cache_base bleibt default (manifest.py DEFAULT_CORE_CACHE_BASE)
        return jsonify(res)

    except Exception as e:
        current_app.logger.exception("core preview failed")
        return jsonify({"ok": False, "error": str(e)}), 400


# --- CORE REPLACE (selective) ----------------------------------------------
@bp.post("/core/replace/preview")
def api_core_replace_preview():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        max_files = int(data.get("max_files") or 5000)
        max_replace = data.get("max_replace", None)
        if max_replace is not None:
            max_replace = int(max_replace)

        allow_changed = bool(data.get("allow_changed", True))
        allow_missing = bool(data.get("allow_missing", False))
        policy = data.get("policy")  # optional dict

        preview = core_replace_preview(
            s["host"], s["port"], s["username"], s["password"],
            wp_root,
            max_files=max_files,
            max_replace=max_replace,
            allow_changed=allow_changed,
            allow_missing=allow_missing,
            policy=policy,
        )
        return jsonify(preview)

    except Exception as e:
        current_app.logger.exception("core replace preview failed")
        return jsonify({"ok": False, "error": str(e)}), 400


@bp.post("/core/replace/apply")
def api_core_replace_apply():
    data = request.get_json(silent=True) or {}
    session_id = (data.get("session_id") or "").strip()
    if not session_id:
        return jsonify({"ok": False, "error": "Missing session_id"}), 400

    try:
        s = _get_session(session_id)
        _, wp_root = _ensure_context(s, data)
        if not wp_root:
            return jsonify({"ok": False, "error": "No wp_root selected"}), 400

        max_files = int(data.get("max_files") or 5000)
        max_replace = int(data.get("max_replace") or 500)
        allow_changed = bool(data.get("allow_changed", True))
        allow_missing = bool(data.get("allow_missing", False))
        policy = data.get("policy")  # optional dict

        # action for rollback
        action = create_action(
            s["host"], s["port"], s["username"], s["password"],
            wp_root=wp_root,
            fix_id="core_replace",
            context={
                "max_files": max_files,
                "max_replace": max_replace,
                "allow_changed": allow_changed,
                "allow_missing": allow_missing,
            }
        )

        result = core_replace_apply(
            s["host"], s["port"], s["username"], s["password"],
            wp_root=wp_root,
            action_meta_path=action["meta_path"],
            action_moved_dir=action["moved_dir"],
            max_files=max_files,
            max_replace=max_replace,
            allow_changed=allow_changed,
            allow_missing=allow_missing,
            policy=policy,
        )

        # meta update + log
        meta_txt = read_text_remote(s["host"], s["port"], s["username"], s["password"], action["meta_path"])
        meta = json.loads(meta_txt)

        meta["status"] = "applied" if result.get("ok") else "failed"
        meta.setdefault("notes", []).append(
            f"core_replace_apply replaced={len(result.get('replaced') or [])} errors={len(result.get('errors') or [])}"
        )
        write_text_remote(
            s["host"], s["port"], s["username"], s["password"],
            action["meta_path"], json.dumps(meta, ensure_ascii=False, indent=2)
        )

        append_log(
            s["host"], s["port"], s["username"], s["password"], wp_root,
            {
                "ts": int(time.time()),
                "type": "fix",
                "fix_id": "core_replace",
                "action_id": action["action_id"],
                "ok": bool(result.get("ok")),
                "replaced": len(result.get("replaced") or []),
                "errors": len(result.get("errors") or []),
            }
        )

        return jsonify({"ok": True, "action_id": action["action_id"], "result": result})

    except Exception as e:
        current_app.logger.exception("core replace apply failed")
        return jsonify({"ok": False, "error": str(e)}), 400
