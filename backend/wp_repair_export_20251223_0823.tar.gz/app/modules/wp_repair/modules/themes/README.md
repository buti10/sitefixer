# themes/

Fix module group:
- switch_default: force WP to use a default theme (SFTP or DB strategy)
- reinstall_theme: quarantine and upload clean theme package
