# switch_default.py
# - SFTP-only strategy: rename active theme folder to force fallback
# - If DB access exists, update template/stylesheet options
# - Store rollback info in meta.json
