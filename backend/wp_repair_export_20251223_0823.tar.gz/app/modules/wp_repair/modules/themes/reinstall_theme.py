# reinstall_theme.py
# - Quarantine existing theme folder
# - Upload clean theme package
# - Postcheck: style.css exists
