# wp_config/

Fix module:
- Validate and patch wp-config.php for common issues
- Always quarantine original before editing
- Use presets for repeatable changes (debug_off, memory limits, etc.)
