from __future__ import annotations

import json
import posixpath
import secrets
import time
from typing import Any, Dict, List

from ..sftp.connect import sftp_connect


def _ts() -> int:
    return int(time.time())


def _action_id(fix_id: str) -> str:
    return f"{time.strftime('%Y%m%d_%H%M%S')}_{fix_id}_{secrets.token_urlsafe(6)}"


def _mkdir_p(sftp, path: str) -> None:
    path = posixpath.normpath(path)
    if path in ("", "/"):
        return
    cur = ""
    for part in path.split("/"):
        if not part:
            continue
        cur += "/" + part
        try:
            sftp.stat(cur)
        except Exception:
            try:
                sftp.mkdir(cur)
            except Exception:
                pass


def _write_text(sftp, path: str, text: str) -> None:
    f = sftp.open(path, "w")
    try:
        f.write(text)
    finally:
        f.close()


def _read_text(sftp, path: str, max_bytes: int = 2_000_000) -> str:
    f = sftp.open(path, "r")
    try:
        data = f.read(max_bytes)
        if isinstance(data, bytes):
            return data.decode("utf-8", errors="replace")
        return str(data)
    finally:
        f.close()


def sitefixer_base(wp_root: str) -> str:
    return posixpath.join(posixpath.normpath(wp_root), ".sitefixer")


def ensure_dirs(host: str, port: int, username: str, password: str, wp_root: str) -> Dict[str, str]:
    """
    Ensure standard directories exist in customer webspace.
    """
    client = sftp_connect(host, port, username, password)
    sftp = client.open_sftp()
    try:
        base = sitefixer_base(wp_root)
        paths = {
            "base": base,
            "state": posixpath.join(base, "state"),
            "logs": posixpath.join(base, "logs"),
            "quarantine": posixpath.join(base, "quarantine"),
            "actions": posixpath.join(base, "quarantine", "actions"),
        }
        for p in paths.values():
            _mkdir_p(sftp, p)
        return paths
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass


def create_action(host: str, port: int, username: str, password: str, wp_root: str, fix_id: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create action folder + meta.json for a fix run.
    """
    paths = ensure_dirs(host, port, username, password, wp_root)
    aid = _action_id(fix_id)
    action_dir = posixpath.join(paths["actions"], aid)
    moved_dir = posixpath.join(action_dir, "moved")
    meta_path = posixpath.join(action_dir, "meta.json")
    log_path = posixpath.join(paths["logs"], "actions.jsonl")

    client = sftp_connect(host, port, username, password)
    sftp = client.open_sftp()
    try:
        _mkdir_p(sftp, action_dir)
        _mkdir_p(sftp, moved_dir)
        meta = {
            "action_id": aid,
            "fix_id": fix_id,
            "created_ts": _ts(),
            "wp_root": posixpath.normpath(wp_root),
            "status": "created",
            "context": context,   # no secrets
            "moved": [],          # list of {"src":..., "dst":...}
            "notes": [],
        }
        _write_text(sftp, meta_path, json.dumps(meta, ensure_ascii=False, indent=2))
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass

    return {
        "action_id": aid,
        "action_dir": action_dir,
        "moved_dir": moved_dir,
        "meta_path": meta_path,
        "log_path": log_path,
    }


def append_log(host: str, port: int, username: str, password: str, wp_root: str, record: Dict[str, Any]) -> None:
    """
    Append JSON line to .sitefixer/logs/actions.jsonl
    """
    paths = ensure_dirs(host, port, username, password, wp_root)
    log_path = posixpath.join(paths["logs"], "actions.jsonl")
    line = json.dumps(record, ensure_ascii=False) + "\n"

    client = sftp_connect(host, port, username, password)
    sftp = client.open_sftp()
    try:
        f = sftp.open(log_path, "a")
        try:
            f.write(line)
        finally:
            f.close()
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass


def quarantine_move(
    host: str,
    port: int,
    username: str,
    password: str,
    src_path: str,
    moved_dir: str,
    meta_path: str,
) -> str:
    """
    Move src_path into moved_dir and record in meta.json.

    - collision safe: if basename already exists in moved_dir, suffix with timestamp
    - records {"src":..., "dst":...} into meta["moved"]
    """
    src_path = posixpath.normpath(src_path)

    client = sftp_connect(host, port, username, password)
    sftp = client.open_sftp()
    try:
        base = posixpath.basename(src_path)
        dst_path = posixpath.join(moved_dir, base)

        # collision safe: if dst exists, append timestamp
        try:
            sftp.stat(dst_path)
            dst_path = posixpath.join(moved_dir, f"{base}.{_ts()}")
        except Exception:
            pass

        # move current file into quarantine
        sftp.rename(src_path, dst_path)

        # update meta.json
        meta = json.loads(_read_text(sftp, meta_path))
        meta.setdefault("moved", []).append({"src": src_path, "dst": dst_path})
        _write_text(sftp, meta_path, json.dumps(meta, ensure_ascii=False, indent=2))

        return dst_path
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass


def rollback(host: str, port: int, username: str, password: str, meta_path: str) -> Dict[str, Any]:
    """
    Rollback:
    1) revert chmod changes (meta["chmod"]) in reverse order (to -> from)
    2) revert moved files (meta["moved"]) in reverse order (dst -> src)
    Notes:
    - If a path no longer exists, we log a note and continue.
    - If dst missing, we log and continue.
    """
    client = sftp_connect(host, port, username, password)
    sftp = client.open_sftp()
    try:
        meta = json.loads(_read_text(sftp, meta_path))
        action_dir = posixpath.dirname(meta_path)  # .../actions/<action_id>
        current_dir = posixpath.join(action_dir, "current")
        _mkdir_p(sftp, current_dir)

        # -------------------------------------------------
        # 1) Revert chmod changes
        # -------------------------------------------------
        chmod_list: List[Dict[str, Any]] = list(meta.get("chmod") or [])
        for ch in reversed(chmod_list):
            path = ch.get("path")

            # support both schemas:
            # A) {"from":"0o644","to":"0o755"}
            # B) {"old_mode":"0o644","new_mode":"0o755"}
            frm = ch.get("from")
            if frm is None:
                frm = ch.get("old_mode")

            if not path or frm is None:
                continue

            try:
                sftp.stat(path)
            except Exception:
                meta.setdefault("notes", []).append(f"rollback chmod skipped (missing): {path}")
                continue

            try:
                sftp.chmod(path, _parse_mode(frm))
            except Exception as e:
                meta.setdefault("notes", []).append(f"rollback chmod failed {path} -> {frm}: {e}")

        # -------------------------------------------------
        # 2) Revert moved files
        # -------------------------------------------------
        moved: List[Dict[str, str]] = list(meta.get("moved") or [])
        for it in reversed(moved):
            src = it.get("src")
            dst = it.get("dst")
            if not src or not dst:
                continue

            # if src exists (current/new file), move aside
            try:
                sftp.stat(src)
                aside_path = posixpath.join(current_dir, posixpath.basename(src))
                try:
                    sftp.remove(aside_path)
                except Exception:
                    pass

                try:
                    sftp.rename(src, aside_path)
                except Exception:
                    # fallback: try deleting src
                    try:
                        sftp.remove(src)
                    except Exception:
                        pass
            except Exception:
                pass

            # restore old file back
            try:
                sftp.rename(dst, src)
            except Exception as e:
                meta.setdefault("notes", []).append(f"rollback move failed {dst} -> {src}: {e}")

        meta["status"] = "rolled_back"
        _write_text(sftp, meta_path, json.dumps(meta, ensure_ascii=False, indent=2))
        return meta
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass

def read_text_remote(host, port, username, password, path, max_bytes=2_000_000) -> str:
    client = sftp_connect(host, port, username, password)
    sftp = client.open_sftp()
    try:
        return _read_text(sftp, path, max_bytes=max_bytes)
    finally:
        try: sftp.close()
        except Exception: pass
        try: client.close()
        except Exception: pass

def write_text_remote(host, port, username, password, path, text: str) -> None:
    client = sftp_connect(host, port, username, password)
    sftp = client.open_sftp()
    try:
        _write_text(sftp, path, text)
    finally:
        try: sftp.close()
        except Exception: pass
        try: client.close()
        except Exception: pass


def _parse_mode(mode_val) -> int:
    """
    Accepts: int, "0o755", "755", "0644"
    Returns: int suitable for sftp.chmod
    """
    if mode_val is None:
        raise ValueError("mode is None")

    if isinstance(mode_val, int):
        return mode_val

    s = str(mode_val).strip().lower()
    # common formats
    if s.startswith("0o"):
        return int(s, 8)
    # "0755" or "755"
    if all(ch in "01234567" for ch in s):
        return int(s, 8)

    raise ValueError(f"Unsupported mode format: {mode_val}")
