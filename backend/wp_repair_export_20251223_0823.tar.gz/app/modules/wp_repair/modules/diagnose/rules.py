# rules.py
# - Data/config for checks (what to run, grouping, thresholds)
# - Keeps diagnose.py simpler and extensible
