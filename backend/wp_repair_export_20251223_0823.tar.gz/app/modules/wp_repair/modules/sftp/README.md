# sftp/

Workflow module:
- Connect via SFTP
- Discover candidate projects
- Provide safe directory listing (explorer)
- Enforce safety rules (path clamp / boundaries)

Used by nearly all other modules.
