# connect.py
# - Establish SFTP connection (host/port/user/password/key)
# - Return a usable session/client handle
# - Enforce timeouts and avoid logging secrets
# app/modules/wp_repair/modules/sftp/connect.py
from __future__ import annotations

import paramiko

def sftp_connect(host: str, port: int, username: str, password: str):
    """
    Returns an active paramiko.SSHClient connected to host.
    Caller may open SFTP via client.open_sftp().
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=host,
        port=port,
        username=username,
        password=password,
        timeout=12,
        banner_timeout=12,
        auth_timeout=12,
        look_for_keys=False,
        allow_agent=False,
    )
    return client
