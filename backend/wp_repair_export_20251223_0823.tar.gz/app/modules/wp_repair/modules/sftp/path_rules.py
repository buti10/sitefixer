# path_rules.py
# - Shared safety rules:
#   - path clamp / normalization
#   - resolve ".sitefixer" base directory on customer webspace
#   - forbidden patterns if needed
