# disable_all.py
# - Disable all plugins by renaming wp-content/plugins folder
# - Create empty plugins folder
# - Store rollback info (old/new names) in meta.json
