# plugins/

Fix module group:
- disable_all: disable all plugins (SFTP rename strategy)
- reinstall_plugin: quarantine and upload clean plugin
- replace_plugin: overwrite/replace plugin files (with quarantine)
