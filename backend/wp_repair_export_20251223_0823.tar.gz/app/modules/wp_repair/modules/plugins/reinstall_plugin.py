# reinstall_plugin.py
# - Quarantine existing wp-content/plugins/<slug>/
# - Upload fresh plugin package from cache/zip
# - Postcheck: main file exists
