# htaccess/

Fix module:
- Repair/replace .htaccess safely
- Always quarantine old .htaccess before writing a new one
- Choose template based on diagnose output (single vs multisite)
