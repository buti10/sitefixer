# verify.py
# - Detect WP version
# - Compare core files to known-good signatures (optional)
# - Output findings to .sitefixer/logs/
