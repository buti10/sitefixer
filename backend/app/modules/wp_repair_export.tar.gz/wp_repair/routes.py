from __future__ import annotations

from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import get_jwt_identity

from app.wp_bridge import get_kundendetails

from .diagnose import run_diagnose
from .sftp_sessions import get_sftp_client
from .audit import read_audit_events

from .actions.cache import disable_dropins_sftp, remove_maintenance_mode_sftp
from .actions.permissions import normalize_permissions_sftp
from .actions.htaccess import reset_htaccess_sftp


from .session_store import store
from .sftp import SftpCreds, connect_sftp, sftp_ls, find_wp_roots

bp = Blueprint("wp_repair", __name__, url_prefix="/api/wp-repair")


def _actor() -> str:
    try:
        ident = get_jwt_identity()
        return str(ident) if ident is not None else "system"
    except Exception:
        return "system"


@bp.post("/diagnose")
def diagnose_route():
    data = request.get_json(silent=True) or {}

    root_path = (data.get("root_path") or "").strip()
    base_url = (data.get("base_url") or "").strip()
    session_id = (data.get("session_id") or "").strip()

    if not root_path or not base_url or not session_id:
        return jsonify({"ok": False, "error": "root_path, base_url, session_id are required"}), 400

    res = run_diagnose(
        root_path=root_path,
        base_url=base_url,
        session_id=session_id,
        verify_ssl=bool(data.get("verify_ssl", True)),
        capture_snippet=bool(data.get("capture_snippet", True)),
        tail_lines=int(data.get("tail_lines", 300)),
        redact_logs=bool(data.get("redact_logs", True)),
    )
    return jsonify(res)


# -------------------------
# Schnell-Fixes (SFTP)
# -------------------------

@bp.post("/fix/htaccess/reset")
def htaccess_reset_route():
    data = request.get_json(silent=True) or {}

    root_path = (data.get("root_path") or "").strip()
    session_id = (data.get("session_id") or "").strip()
    ticket_id = data.get("ticket_id")
    dry_run = bool(data.get("dry_run", True))
    keep_custom_above = bool(data.get("keep_custom_above", False))

    if not root_path or not session_id:
        return jsonify({"ok": False, "error": "root_path and session_id are required"}), 400

    try:
        client, sftp = get_sftp_client(session_id)
    except Exception as e:
        return jsonify({"ok": False, "error": f"SFTP session invalid: {e}"}), 401

    try:
        result = reset_htaccess_sftp(
            actor=_actor(),
            sftp=sftp,
            root_path=root_path,
            dry_run=dry_run,
            keep_custom_above=keep_custom_above,
            ticket_id=ticket_id,
        )
        return jsonify(result), (200 if result.get("ok") else 500)

    except Exception as e:
        current_app.logger.exception("htaccess reset failed")
        return jsonify({"ok": False, "error": str(e)}), 500

    finally:
        try:
            sftp.close()
            client.close()
        except Exception:
            pass


@bp.post("/fix/permissions/normalize")
def permissions_normalize_route():
    data = request.get_json(silent=True) or {}

    root_path = (data.get("root_path") or "").strip()
    session_id = (data.get("session_id") or "").strip()
    ticket_id = data.get("ticket_id")
    target = (data.get("target") or "").strip()
    dry_run = bool(data.get("dry_run", True))

    if not root_path or not session_id:
        return jsonify({"ok": False, "error": "root_path and session_id are required"}), 400

    try:
        client, sftp = get_sftp_client(session_id)
    except Exception as e:
        return jsonify({"ok": False, "error": f"SFTP session invalid: {e}"}), 401

    try:
        result = normalize_permissions_sftp(
            actor=_actor(),
            sftp=sftp,
            root_path=root_path,
            target_rel_or_abs=target,
            dry_run=dry_run,
            ticket_id=ticket_id,
        )
        return jsonify(result), (200 if result.get("ok") else 500)

    except Exception as e:
        current_app.logger.exception("permissions normalize failed")
        return jsonify({"ok": False, "error": str(e)}), 500

    finally:
        try:
            sftp.close()
            client.close()
        except Exception:
            pass


@bp.post("/fix/cache/disable-dropins")
def cache_disable_dropins_route():
    data = request.get_json(silent=True) or {}

    root_path = (data.get("root_path") or "").strip()
    session_id = (data.get("session_id") or "").strip()
    ticket_id = data.get("ticket_id")
    dry_run = bool(data.get("dry_run", True))
    rename_suffix = (data.get("rename_suffix") or ".disabled").strip()
    backup_before = bool(data.get("backup_before", True))

    if not root_path or not session_id:
        return jsonify({"ok": False, "error": "root_path and session_id are required"}), 400

    try:
        client, sftp = get_sftp_client(session_id)
    except Exception as e:
        return jsonify({"ok": False, "error": f"SFTP session invalid: {e}"}), 401

    try:
        result = disable_dropins_sftp(
            actor=_actor(),
            sftp=sftp,
            root_path=root_path,
            dry_run=dry_run,
            rename_suffix=rename_suffix,
            backup_before=backup_before,
            ticket_id=ticket_id,
        )
        return jsonify(result), (200 if result.get("ok") else 500)

    except Exception as e:
        current_app.logger.exception("dropins disable failed")
        return jsonify({"ok": False, "error": str(e)}), 500

    finally:
        try:
            sftp.close()
            client.close()
        except Exception:
            pass


@bp.post("/fix/maintenance/remove")
def maintenance_remove_route():
    data = request.get_json(silent=True) or {}

    root_path = (data.get("root_path") or "").strip()
    session_id = (data.get("session_id") or "").strip()
    ticket_id = data.get("ticket_id")
    dry_run = bool(data.get("dry_run", True))
    backup_before = bool(data.get("backup_before", True))

    if not root_path or not session_id:
        return jsonify({"ok": False, "error": "root_path and session_id are required"}), 400

    try:
        client, sftp = get_sftp_client(session_id)
    except Exception as e:
        return jsonify({"ok": False, "error": f"SFTP session invalid: {e}"}), 401

    try:
        result = remove_maintenance_mode_sftp(
            actor=_actor(),
            sftp=sftp,
            root_path=root_path,
            dry_run=dry_run,
            backup_before=backup_before,
            ticket_id=ticket_id,
        )
        return jsonify(result), (200 if result.get("ok") else 500)

    except Exception as e:
        current_app.logger.exception("maintenance remove failed")
        return jsonify({"ok": False, "error": str(e)}), 500

    finally:
        try:
            sftp.close()
            client.close()
        except Exception:
            pass


# -------------------------
# SFTP Wizard
# -------------------------

def _ticket_sftp_access(ticket: dict) -> tuple[str, str, str, int]:
    host = ticket.get("ftp_host") or ticket.get("ftp_server") or ""
    user = ticket.get("ftp_user") or ""
    pw = ticket.get("ftp_pass") or ""
    port = int(ticket.get("ftp_port") or ticket.get("sftp_port") or 22)

    if not host or not user or not pw:
        raise ValueError("Ticket hat keine vollständigen SFTP Zugangsdaten (host/user/pass).")

    return host, user, pw, port


@bp.post("/tickets/<int:ticket_id>/sftp/connect")
def sftp_connect_route(ticket_id: int):
    ticket = get_kundendetails(ticket_id)
    if not ticket:
        return jsonify({"error": "Ticket nicht gefunden"}), 404

    try:
        host, user, pw, port = _ticket_sftp_access(ticket)

        client, sftp = connect_sftp(SftpCreds(host=host, username=user, password=pw, port=port))
        sftp.close()
        client.close()

        sid = store.create({"host": host, "user": user, "pass": pw, "port": port}, ttl_seconds=1800)
        return jsonify({"sftp_session_id": sid, "expires_in": 1800})

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@bp.get("/sftp/<session_id>/projects")
def sftp_projects_route(session_id: str):
    s = store.get(session_id)
    if not s:
        return jsonify({"error": "Session ungültig oder abgelaufen."}), 400

    creds = SftpCreds(
        host=s.data["host"],
        username=s.data["user"],
        password=s.data["pass"],
        port=int(s.data.get("port", 22)),
    )

    try:
        client, sftp = connect_sftp(creds)
        items = find_wp_roots(sftp, start="/", max_depth=7)
        sftp.close()
        client.close()
        return jsonify({"items": items})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@bp.get("/sftp/<session_id>/ls")
def sftp_ls_route(session_id: str):
    s = store.get(session_id)
    if not s:
        return jsonify({"error": "Session ungültig oder abgelaufen."}), 400

    path = (request.args.get("path") or "/").strip() or "/"
    creds = SftpCreds(
        host=s.data["host"],
        username=s.data["user"],
        password=s.data["pass"],
        port=int(s.data.get("port", 22)),
    )

    try:
        client, sftp = connect_sftp(creds)
        items = sftp_ls(sftp, path)
        sftp.close()
        client.close()
        return jsonify({"items": items})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@bp.post("/tickets/<int:ticket_id>/root")
def set_root_route(ticket_id: int):
    data = request.get_json(silent=True) or {}
    root_path = (data.get("root_path") or "").strip()
    if not root_path:
        return jsonify({"error": "root_path is required"}), 400

    key = f"root:{ticket_id}"
    store.create({"key": key, "root_path": root_path}, ttl_seconds=7 * 24 * 3600)
    return jsonify({"ok": True, "root_path": root_path})


# -------------------------
# Audit / Verlauf
# -------------------------

@bp.get("/actions")
def actions_list():
    root_path = (request.args.get("root_path") or "").strip()
    ticket_id = request.args.get("ticket_id", type=int)

    items = read_audit_events(limit=50, root_path=root_path, ticket_id=ticket_id)
    return jsonify({"ok": True, "items": items})


@bp.post("/actions/<action_id>/rollback")
def rollback_action(action_id: str):
    # Rollback ist in deinem Code noch nicht vollständig implementiert (Artifact Lookup fehlt).
    return jsonify({"ok": False, "error": "rollback not implemented yet"}), 501
