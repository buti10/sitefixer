import posixpath
import time
import uuid
from ..audit import audit_started, audit_success, audit_failed

WP_HTACCESS_DEFAULT = """# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
"""

def reset_htaccess_sftp(*, actor, sftp, root_path, dry_run=True, keep_custom_above=False, ticket_id=None):
    action_id = f"htaccess_reset:{uuid.uuid4().hex}"
    htaccess_path = posixpath.join(root_path.rstrip("/"), ".htaccess")

    params = {
        "dry_run": bool(dry_run),
        "keep_custom_above": bool(keep_custom_above),
        "ticket_id": ticket_id,
    }

    audit_started(actor=actor, root_path=root_path, action_id=action_id, params=params, meta={"ticket_id": ticket_id})

    exists = True
    try:
        sftp.stat(htaccess_path)
    except Exception:
        exists = False

    try:
        if dry_run:
            res = {
                "ok": True,
                "action_id": action_id,
                "dry_run": True,
                "path": htaccess_path,
                "exists": exists,
                "message": "Dry-Run: htaccess would be written",
            }
            audit_success(actor=actor, root_path=root_path, action_id=action_id, params=params, result=res, meta={"ticket_id": ticket_id})
            return res

        content = WP_HTACCESS_DEFAULT.strip() + "\n"
        tmp = htaccess_path + f".tmp_{int(time.time())}"
        with sftp.open(tmp, "w") as f:
            f.write(content)

        try:
            sftp.posix_rename(tmp, htaccess_path)
        except Exception:
            sftp.rename(tmp, htaccess_path)

        res = {
            "ok": True,
            "action_id": action_id,
            "dry_run": False,
            "path": htaccess_path,
            "written": True,
        }
        audit_success(actor=actor, root_path=root_path, action_id=action_id, params=params, result=res, meta={"ticket_id": ticket_id})
        return res

    except Exception as e:
        audit_failed(actor=actor, root_path=root_path, action_id=action_id, params=params, error=str(e), meta={"ticket_id": ticket_id})
        return {"ok": False, "action_id": action_id, "error": str(e), "path": htaccess_path}
