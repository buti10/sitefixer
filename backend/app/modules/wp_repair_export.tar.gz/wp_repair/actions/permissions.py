from __future__ import annotations

import os
import posixpath
import stat
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..audit import audit_started, audit_success, audit_failed
from ..backup import backup_file


DEFAULT_DIR_MODE = 0o755
DEFAULT_FILE_MODE = 0o644
WPCONFIG_MODE = 0o640

# Hard limits to avoid runaway recursion on huge accounts
MAX_ITEMS = int(os.getenv("WP_REPAIR_PERM_MAX_ITEMS", "120000"))
MAX_DEPTH = int(os.getenv("WP_REPAIR_PERM_MAX_DEPTH", "25"))


@dataclass
class PermChange:
    path: str
    kind: str  # "file"|"dir"|"other"
    before: Optional[str]
    after: Optional[str]
    changed: bool
    error: Optional[str] = None


# ---------------------------
# Local FS helpers (existing)
# ---------------------------

def _safe_realpath(p: str) -> Path:
    return Path(p).expanduser().resolve(strict=False)


def _oct_mode(p: Path) -> Optional[str]:
    try:
        m = stat.S_IMODE(p.lstat().st_mode)
        return oct(m)
    except Exception:
        return None


def _should_skip(path: Path) -> bool:
    # Skip symlinks (important security + avoids leaving root)
    try:
        if path.is_symlink():
            return True
    except Exception:
        return True
    return False


def _iter_tree(root: Path) -> Tuple[List[Path], List[str]]:
    """
    Returns (paths, warnings)
    BFS traversal with depth + count limits.
    """
    warnings: List[str] = []
    out: List[Path] = []

    q: List[Tuple[Path, int]] = [(root, 0)]
    seen = 0

    while q:
        p, depth = q.pop(0)
        if depth > MAX_DEPTH:
            warnings.append(f"Max depth reached at {p}")
            continue

        if _should_skip(p):
            continue

        out.append(p)
        seen += 1
        if seen >= MAX_ITEMS:
            warnings.append(f"Max item limit reached ({MAX_ITEMS}). Stopped early.")
            break

        try:
            if p.is_dir():
                for child in p.iterdir():
                    q.append((child, depth + 1))
        except Exception as e:
            warnings.append(f"Cannot read dir {p}: {type(e).__name__}: {e}")

    return out, warnings


def normalize_permissions(
    *,
    actor: str,
    root_path: str,
    target_rel_or_abs: str = "",
    dry_run: bool = False,
    dir_mode: int = DEFAULT_DIR_MODE,
    file_mode: int = DEFAULT_FILE_MODE,
    wpconfig_mode: int = WPCONFIG_MODE,
    backup_wpconfig: bool = True,
) -> Dict[str, Any]:
    """
    Local filesystem version (unchanged).
    """
    action_id = "fix.permissions.normalize"
    params = {
        "target": target_rel_or_abs or ".",
        "dry_run": dry_run,
        "dir_mode": oct(dir_mode),
        "file_mode": oct(file_mode),
        "wpconfig_mode": oct(wpconfig_mode),
        "mode": "local",
    }

    root = _safe_realpath(root_path)
    target = (
        _safe_realpath(str(root / target_rel_or_abs))
        if target_rel_or_abs and not os.path.isabs(target_rel_or_abs)
        else _safe_realpath(target_rel_or_abs or str(root))
    )

    audit_started(actor=actor, root_path=str(root), action_id=action_id, params=params)

    wpconfig = root / "wp-config.php"
    backup_meta = None
    try:
        if backup_wpconfig and wpconfig.exists() and wpconfig.is_file() and not dry_run:
            backup_meta = backup_file(
                root_path=str(root),
                target_rel_or_abs=str(wpconfig),
                label="permissions_wpconfig_backup",
                compute_sha256=True,
            )
            if not backup_meta.get("ok"):
                audit_failed(
                    actor=actor,
                    root_path=str(root),
                    action_id=action_id,
                    params=params,
                    error=f"Backup wp-config.php failed: {backup_meta.get('error')}",
                    backup=backup_meta,
                )
                return {"ok": False, "error": "Backup wp-config.php failed", "backup": backup_meta}

        paths, warnings = _iter_tree(target)

        changes: List[PermChange] = []
        changed_count = 0
        error_count = 0

        for p in paths:
            if _should_skip(p):
                continue

            before = _oct_mode(p)
            kind = "dir" if p.is_dir() else "file" if p.is_file() else "other"

            desired = None
            if kind == "dir":
                desired = dir_mode
            elif kind == "file":
                if p.resolve(strict=False) == wpconfig.resolve(strict=False):
                    desired = wpconfig_mode
                else:
                    desired = file_mode

            if desired is None:
                continue

            after = oct(desired)
            changed = (before != after)

            if changed and not dry_run:
                try:
                    os.chmod(p, desired)
                except Exception as e:
                    error_count += 1
                    changes.append(PermChange(
                        path=str(p),
                        kind=kind,
                        before=before,
                        after=after,
                        changed=False,
                        error=f"{type(e).__name__}: {e}",
                    ))
                    continue

            if changed:
                changed_count += 1

            if changed or kind == "other":
                changes.append(PermChange(
                    path=str(p),
                    kind=kind,
                    before=before,
                    after=after,
                    changed=changed,
                ))

        MAX_RETURN = 500
        changes_out = [asdict(c) for c in changes[:MAX_RETURN]]

        res = {
            "ok": True,
            "target": str(target),
            "dry_run": dry_run,
            "changed": changed_count,
            "errors": error_count,
            "warnings": warnings,
            "changes_sample": changes_out,
            "truncated": len(changes) > MAX_RETURN,
            "mode": "local",
        }

        audit_success(
            actor=actor,
            root_path=str(root),
            action_id=action_id,
            params=params,
            result=res,
            backup=backup_meta,
        )
        return res

    except Exception as e:
        audit_failed(
            actor=actor,
            root_path=str(root),
            action_id=action_id,
            params=params,
            error=f"{type(e).__name__}: {e}",
            backup=backup_meta,
        )
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "backup": backup_meta}


# ---------------------------
# SFTP helpers (NEW)
# ---------------------------

def _sftp_stat(sftp, p: str):
    return sftp.stat(p)


def _sftp_kind(mode: int) -> str:
    if stat.S_ISDIR(mode):
        return "dir"
    if stat.S_ISREG(mode):
        return "file"
    if stat.S_ISLNK(mode):
        return "symlink"
    return "other"


def _sftp_oct_mode(mode: int) -> str:
    return oct(stat.S_IMODE(mode))


def _sftp_is_within(root: str, p: str) -> bool:
    # normalize posix paths and ensure p starts with root
    root_n = posixpath.normpath(root).rstrip("/")
    p_n = posixpath.normpath(p)
    return p_n == root_n or p_n.startswith(root_n + "/")


def _iter_tree_sftp(sftp, start: str, root: str) -> Tuple[List[Tuple[str, str, str]], List[str]]:
    """
    BFS traversal over SFTP.
    Returns list of tuples: (path, kind, before_oct) and warnings
    Skips symlinks.
    Enforces MAX_ITEMS and MAX_DEPTH.
    """
    warnings: List[str] = []
    out: List[Tuple[str, str, str]] = []

    start = posixpath.normpath(start) or "/"
    root = posixpath.normpath(root) or "/"

    q: List[Tuple[str, int]] = [(start, 0)]
    seen = 0

    while q:
        p, depth = q.pop(0)
        if depth > MAX_DEPTH:
            warnings.append(f"Max depth reached at {p}")
            continue

        # safety: never leave root
        if not _sftp_is_within(root, p):
            warnings.append(f"Skipped outside root: {p}")
            continue

        try:
            st = _sftp_stat(sftp, p)
            kind = _sftp_kind(st.st_mode)
            before = _sftp_oct_mode(st.st_mode)
        except Exception as e:
            warnings.append(f"Cannot stat {p}: {type(e).__name__}: {e}")
            continue

        # skip symlinks
        if kind == "symlink":
            continue

        out.append((p, kind, before))
        seen += 1
        if seen >= MAX_ITEMS:
            warnings.append(f"Max item limit reached ({MAX_ITEMS}). Stopped early.")
            break

        if kind == "dir":
            try:
                for ent in sftp.listdir_attr(p):
                    child = posixpath.join(p.rstrip("/"), ent.filename)
                    q.append((child, depth + 1))
            except Exception as e:
                warnings.append(f"Cannot read dir {p}: {type(e).__name__}: {e}")

    return out, warnings


def normalize_permissions_sftp(
    *,
    actor: str,
    sftp,
    root_path: str,
    target_rel_or_abs: str = "",
    dry_run: bool = True,
    dir_mode: int = DEFAULT_DIR_MODE,
    file_mode: int = DEFAULT_FILE_MODE,
    wpconfig_mode: int = WPCONFIG_MODE,
    backup_wpconfig: bool = False,
    ticket_id: Optional[int] = None,
) -> Dict[str, Any]:
    """
    SFTP version for Repair-Beta.
    - Directories -> 755
    - Files -> 644
    - wp-config.php -> 640
    - Skips symlinks
    - Does NOT use local backup_file() (different FS). Backups should be handled by the SFTP-actions layer if needed.
    """
    action_id = "fix.permissions.normalize"

    root = posixpath.normpath(root_path).rstrip("/")
    if not root:
        return {"ok": False, "error": "root_path is required"}

    # target can be abs or relative to root
    if target_rel_or_abs:
        start = target_rel_or_abs.strip()
        target = posixpath.normpath(start) if start.startswith("/") else posixpath.normpath(posixpath.join(root, start))
    else:
        target = root

    params = {
        "target": target_rel_or_abs or ".",
        "dry_run": dry_run,
        "dir_mode": oct(dir_mode),
        "file_mode": oct(file_mode),
        "wpconfig_mode": oct(wpconfig_mode),
        "mode": "sftp",
        "ticket_id": ticket_id,
    }

    audit_started(actor=actor, root_path=root, action_id=action_id, params=params)

    backup_meta = None
    try:
        # optional: if you later implement SFTP backup for wp-config, do it in your SFTP backup layer
        # (backup_wpconfig kept for signature compatibility)
        wpconfig_path = posixpath.join(root, "wp-config.php")

        items, warnings = _iter_tree_sftp(sftp, target, root)

        changes: List[PermChange] = []
        changed_count = 0
        error_count = 0

        for p, kind, before in items:
            if kind not in ("dir", "file"):
                continue

            desired = None
            if kind == "dir":
                desired = dir_mode
            elif kind == "file":
                # wp-config special case
                if posixpath.normpath(p) == posixpath.normpath(wpconfig_path):
                    desired = wpconfig_mode
                else:
                    desired = file_mode

            after = oct(desired)
            changed = (before != after)

            if changed and not dry_run:
                try:
                    sftp.chmod(p, desired)
                except Exception as e:
                    error_count += 1
                    changes.append(PermChange(
                        path=p,
                        kind=kind,
                        before=before,
                        after=after,
                        changed=False,
                        error=f"{type(e).__name__}: {e}",
                    ))
                    continue

            if changed:
                changed_count += 1

            if changed:
                changes.append(PermChange(
                    path=p,
                    kind=kind,
                    before=before,
                    after=after,
                    changed=changed,
                ))

        MAX_RETURN = 500
        changes_out = [asdict(c) for c in changes[:MAX_RETURN]]

        res = {
            "ok": True,
            "target": target,
            "dry_run": dry_run,
            "changed": changed_count,
            "errors": error_count,
            "warnings": warnings,
            "changes_sample": changes_out,
            "truncated": len(changes) > MAX_RETURN,
            "mode": "sftp",
        }

        audit_success(
            actor=actor,
            root_path=root,
            action_id=action_id,
            params=params,
            result=res,
            backup=backup_meta,
        )
        return res

    except Exception as e:
        audit_failed(
            actor=actor,
            root_path=root,
            action_id=action_id,
            params=params,
            error=f"{type(e).__name__}: {e}",
            backup=backup_meta,
        )
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "backup": backup_meta}
