from __future__ import annotations

import posixpath
import time
import uuid
from typing import Any, Dict, List, Optional

from ..audit import audit_started, audit_success, audit_failed


# -----------------------
# helpers
# -----------------------

def _pjoin(a: str, b: str) -> str:
    return posixpath.join(a.rstrip("/"), b.lstrip("/"))


def _sftp_exists(sftp, path: str) -> bool:
    try:
        sftp.stat(path)
        return True
    except Exception:
        return False


def _sftp_is_file(sftp, path: str) -> bool:
    try:
        st = sftp.stat(path)
        import stat as _stat
        return _stat.S_ISREG(st.st_mode)
    except Exception:
        return False


def _sftp_is_dir(sftp, path: str) -> bool:
    try:
        st = sftp.stat(path)
        import stat as _stat
        return _stat.S_ISDIR(st.st_mode)
    except Exception:
        return False


def _sftp_rename(sftp, src: str, dst: str) -> None:
    # Prefer atomic rename if available
    try:
        sftp.posix_rename(src, dst)  # paramiko
    except Exception:
        sftp.rename(src, dst)


def _unique_suffix(suffix: str) -> str:
    return f"{suffix}_{int(time.time())}_{uuid.uuid4().hex[:8]}"


# =========================================================
# SFTP: Drop-ins disable (Repair-Beta uses SFTP session)
# =========================================================

def disable_dropins_sftp(
    *,
    actor: str,
    sftp,
    root_path: str,
    dry_run: bool = True,
    rename_suffix: str = ".disabled",
    backup_before: bool = True,
    ticket_id: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Disables common caching drop-ins safely by renaming (SFTP):
      - wp-content/object-cache.php
      - wp-content/advanced-cache.php
      - wp-content/db.php
    Also detects cache dirs and .maintenance (does not delete cache dirs).

    NOTE:
    - "backup_before" is kept for compatibility; on SFTP, the rename itself is effectively the backup.
    """
    action_id = f"dropins_disable:{uuid.uuid4().hex}"
    params = {
        "dry_run": bool(dry_run),
        "rename_suffix": rename_suffix,
        "backup_before": bool(backup_before),
        "ticket_id": ticket_id,
    }

    root = root_path.rstrip("/") or "/"
    wp_content = _pjoin(root, "wp-content")

    targets = [
        _pjoin(wp_content, "object-cache.php"),
        _pjoin(wp_content, "advanced-cache.php"),
        _pjoin(wp_content, "db.php"),
    ]

    audit_started(actor=actor, root_path=root, action_id=action_id, params=params, meta={"ticket_id": ticket_id})

    changed: List[Dict[str, Any]] = []
    warnings: List[str] = []

    try:
        for t in targets:
            if not _sftp_exists(sftp, t) or not _sftp_is_file(sftp, t):
                continue

            new_name = t + rename_suffix
            # ensure unique
            if _sftp_exists(sftp, new_name):
                new_name = t + _unique_suffix(rename_suffix)

            if dry_run:
                changed.append({"path": t, "would_rename_to": new_name})
                continue

            _sftp_rename(sftp, t, new_name)
            changed.append({"path": t, "renamed_to": new_name})

        # Detections only
        cache_dir = _pjoin(wp_content, "cache")
        w3tc_dir = _pjoin(wp_content, "w3tc-config")
        litespeed_dir = _pjoin(wp_content, "litespeed")
        maintenance = _pjoin(root, ".maintenance")

        detections = {
            "cache_dir": cache_dir if _sftp_is_dir(sftp, cache_dir) else None,
            "w3tc_config": w3tc_dir if _sftp_is_dir(sftp, w3tc_dir) else None,
            "litespeed": litespeed_dir if _sftp_is_dir(sftp, litespeed_dir) else None,
            "maintenance": maintenance if _sftp_exists(sftp, maintenance) else None,
        }

        res = {
            "ok": True,
            "action_id": action_id,
            "dry_run": bool(dry_run),
            "changed": changed,
            "detections": detections,
            "warnings": warnings,
            "note": "Drop-ins were renamed (not deleted). Cache directories were only detected.",
        }

        audit_success(actor=actor, root_path=root, action_id=action_id, params=params, result=res, meta={"ticket_id": ticket_id})
        return res

    except Exception as e:
        audit_failed(actor=actor, root_path=root, action_id=action_id, params=params, error=f"{type(e).__name__}: {e}", meta={"ticket_id": ticket_id})
        return {"ok": False, "action_id": action_id, "error": f"{type(e).__name__}: {e}"}


# =========================================================
# SFTP: remove .maintenance
# =========================================================

def remove_maintenance_mode_sftp(
    *,
    actor: str,
    sftp,
    root_path: str,
    dry_run: bool = True,
    backup_before: bool = True,
    ticket_id: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Removes .maintenance file via SFTP.
    If backup_before=True, the file is renamed to a .bak_* instead of deleting (safer).
    """
    action_id = f"maintenance_remove:{uuid.uuid4().hex}"
    params = {
        "dry_run": bool(dry_run),
        "backup_before": bool(backup_before),
        "ticket_id": ticket_id,
    }

    root = root_path.rstrip("/") or "/"
    m = _pjoin(root, ".maintenance")

    audit_started(actor=actor, root_path=root, action_id=action_id, params=params, meta={"ticket_id": ticket_id})

    try:
        if not _sftp_exists(sftp, m):
            res = {"ok": True, "action_id": action_id, "removed": False, "path": m, "note": ".maintenance not present"}
            audit_success(actor=actor, root_path=root, action_id=action_id, params=params, result=res, meta={"ticket_id": ticket_id})
            return res

        if dry_run:
            res = {"ok": True, "action_id": action_id, "dry_run": True, "path": m, "would_remove": True}
            audit_success(actor=actor, root_path=root, action_id=action_id, params=params, result=res, meta={"ticket_id": ticket_id})
            return res

        if backup_before:
            bak = m + _unique_suffix(".bak")
            _sftp_rename(sftp, m, bak)
            res = {"ok": True, "action_id": action_id, "removed": True, "path": m, "backup_path": bak, "mode": "rename_backup"}
        else:
            sftp.remove(m)
            res = {"ok": True, "action_id": action_id, "removed": True, "path": m, "mode": "delete"}

        audit_success(actor=actor, root_path=root, action_id=action_id, params=params, result=res, meta={"ticket_id": ticket_id})
        return res

    except Exception as e:
        audit_failed(actor=actor, root_path=root, action_id=action_id, params=params, error=f"{type(e).__name__}: {e}", meta={"ticket_id": ticket_id})
        return {"ok": False, "action_id": action_id, "error": f"{type(e).__name__}: {e}"}


# =========================================================
# Optional: keep local functions (harmless)
# (If you still want your old local implementations, keep them
# in a separate file like cache_local.py to avoid confusion.)
# =========================================================
